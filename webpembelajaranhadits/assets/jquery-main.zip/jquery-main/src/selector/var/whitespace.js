// https://www.w3.org/TR/css3-selectors/#whitespace
export default "[\\x20\\t\\r\\n\\f]";
