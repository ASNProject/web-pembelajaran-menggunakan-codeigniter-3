export default window.location;
